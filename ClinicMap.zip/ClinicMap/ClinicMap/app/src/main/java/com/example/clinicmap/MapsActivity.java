package com.example.clinicmap;

import androidx.annotation.DrawableRes;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.Task;
import com.google.maps.android.data.Feature;
import com.google.maps.android.data.Geometry;
import com.google.maps.android.data.geojson.GeoJsonFeature;
import com.google.maps.android.data.geojson.GeoJsonLayer;
import com.google.maps.android.data.geojson.GeoJsonPointStyle;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;

import static java.lang.Double.parseDouble;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    public static GoogleMap mMap;
    public static LatLng liveLocation;
    public static Marker curMarker;
    //public static ArrayList<MarkerOptions> clinicMarkers;
    private LocationManager locationManager;
    private LocationListener locationListener;
    SupportMapFragment mapFragment;


    //live location permissions
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == 1) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    locationManager.requestLocationUpdates(locationManager.GPS_PROVIDER, 0, 0, locationListener);
                }

            }
        }
    }


    @SuppressLint("MissingPermission")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);

        mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);

        AutoCompleteTextView editText = findViewById(R.id.search);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, getClinicNames());
        editText.setAdapter(adapter);

        mapFragment.getMapAsync(this);
    }


    private BitmapDescriptor bitmapDescriptorFromVector(Context context, @DrawableRes int vectorResId) {
        Drawable vectorDrawable = ContextCompat.getDrawable(context, vectorResId);
        vectorDrawable.setBounds(0, 0, vectorDrawable.getIntrinsicWidth(), vectorDrawable.getIntrinsicHeight());
        Bitmap bitmap = Bitmap.createBitmap(vectorDrawable.getIntrinsicWidth(), vectorDrawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        vectorDrawable.draw(canvas);
        return BitmapDescriptorFactory.fromBitmap(bitmap);
    }


    @SuppressLint("MissingPermission")
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        LatLngBounds sgBounds = new LatLngBounds(
                new LatLng(1.2046, 103.5292), // SW bounds
                new LatLng(1.4585, 104.0490)  // NE bounds
        );

        //Live location
        locationManager= (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);
        locationListener=new LocationListener() {
            @Override
            public void onLocationChanged(@NonNull Location location) {

                liveLocation = new LatLng(location.getLatitude(),location.getLongitude());
                if(curMarker!=null){
                    curMarker.remove();
                }
                curMarker= mMap.addMarker(new MarkerOptions().position(liveLocation).title("My Location")
                        .icon(bitmapDescriptorFromVector(MapsActivity.this, R.drawable.ic_livemarker)));
            }
        };
        if(Build.VERSION.SDK_INT<23){
            locationManager.requestLocationUpdates(locationManager.GPS_PROVIDER, 0, 0, locationListener);
        }
        else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1); //could be any number*//*);
            } else {
                locationManager.requestLocationUpdates(locationManager.GPS_PROVIDER, 0, 0, locationListener);
                Location lastKnownLocation = null;
                while (lastKnownLocation==null) {
                    lastKnownLocation=locationManager.getLastKnownLocation(locationManager.GPS_PROVIDER);
                    if (lastKnownLocation!=null){
                        liveLocation = new LatLng(lastKnownLocation.getLatitude(), lastKnownLocation.getLongitude());
                        break;
                    }
                }
            }
        }

        try {
            GeoJsonLayer clinicLayer = new GeoJsonLayer(mMap, R.raw.clinics_geo, this);
            clinicLayer.addLayerToMap();

            /*// Add a marker and move the camera
            LatLng plazaSing = new LatLng(1.3005, 103.8452);
            mMap.addMarker(new MarkerOptions().position(plazaSing).title("Marker in Singapore"));
            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(plazaSing,11));*/

        } catch (JSONException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        mMap.getUiSettings().setZoomControlsEnabled(true);
        mMap.getUiSettings().setMapToolbarEnabled(false);
        mMap.setLatLngBoundsForCameraTarget(sgBounds);
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(liveLocation, 14));
        mMap.setMinZoomPreference(10.0f);
    }

    public String[] getClinicNames() {
        String[] allNames = new String[5];
        int i = 0;
        try {
            GeoJsonLayer clinicLayer = new GeoJsonLayer(mMap, R.raw.clinics_geo, this);

            for (GeoJsonFeature feature : clinicLayer.getFeatures()) {
                String clinicName = feature.getProperty("name");
                Double clinicLat = Double.parseDouble(feature.getProperty("lat"));
                Double clinicLong = Double.parseDouble(feature.getProperty("long"));
                LatLng clinicCoord = new LatLng(clinicLat, clinicLong);
                allNames[i] = clinicName;
                i++;
                //System.out.println(clinicCoord);
                //System.out.println(clinicName);




                /*MarkerOptions clinicInfo = new MarkerOptions()
                        .position(clinicCoord)
                        .title(clinicName)
                        .icon(BitmapDescriptorFactory
                                .defaultMarker(BitmapDescriptorFactory.HUE_AZURE));
                mMap.addMarker(clinicInfo);*/



            }


            return allNames;
        } catch (JSONException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return allNames;
    }






}